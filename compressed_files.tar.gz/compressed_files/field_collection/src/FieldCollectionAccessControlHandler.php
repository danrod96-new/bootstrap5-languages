<?php

namespace Drupal\field_collection;

use Drupal\Core\Entity\EntityAccessControlHandler;

class FieldCollectionAccessControlHandler extends EntityAccessControlHandler {

}
